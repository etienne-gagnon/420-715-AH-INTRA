# 420-715-AH-INTRA
Intra du cours développement de suites de test et livraison continue

Avant de commancer, tapper les commandes suivantes dans le terminal : 
1. npm init
-  Écrire pour main : server.js
2. npm install
3. npm install express
4. npm install --save-dev @cucumber/cucumber
5. node server
6. Aller sur http://localhost:7777

Lien github : https://github.com/etienne-gagnon/420-715-AH-INTRA.git


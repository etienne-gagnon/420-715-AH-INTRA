const express = require('express');
const app = express();

app.get('/', function (req, res) {
    res.sendFile(__dirname + '/index.html');
})



app.listen(7777);

console.log('Le server est ouvert : http://localhost:7777');